   0:# INIT TABLES
   3:# 
   4:# ======= START RUNG 1 =======
   5:LabelRung1:
   6:
   7:set bit '$rung_top'
   9:# start series [
  10:# start parallel [
  11:clear bit '$parOut_0'
  12:let bit '$parThis_0' := '$rung_top'
  13:# start series [
  14:# start parallel [
  15:clear bit '$parOut_1'
  16:let bit '$parThis_1' := '$parThis_0'
  17:# ELEM_CONTACTS
  18:if not 'XSTART' {
  19:    clear bit '$parThis_1'
  20:}
  22:if '$parThis_1' {
  23:    set bit '$parOut_1'
  24:}
  25:let bit '$parThis_1' := '$parThis_0'
  26:# ELEM_CONTACTS
  27:if not 'YFan' {
  28:    clear bit '$parThis_1'
  29:}
  31:if '$parThis_1' {
  32:    set bit '$parOut_1'
  33:}
  34:let bit '$parThis_0' := '$parOut_1'
  35:# ] finish parallel
  36:# ELEM_CONTACTS
  37:if 'XStop' {
  38:    clear bit '$parThis_0'
  39:}
  41:# ] finish series
  42:if '$parThis_0' {
  43:    set bit '$parOut_0'
  44:}
  45:let bit '$parThis_0' := '$rung_top'
  46:# ELEM_CONTACTS
  47:if not 'XTest' {
  48:    clear bit '$parThis_0'
  49:}
  51:if '$parThis_0' {
  52:    set bit '$parOut_0'
  53:}
  54:let bit '$rung_top' := '$parOut_0'
  55:# ] finish parallel
  56:# ELEM_CONTACTS
  57:if 'XErr' {
  58:    clear bit '$rung_top'
  59:}
  61:# ELEM_COIL
  62:let bit 'YFan' := '$rung_top'
  64:# ] finish series
  65:LabelRung2:
  66:
  67:# Latest INT_OP here
