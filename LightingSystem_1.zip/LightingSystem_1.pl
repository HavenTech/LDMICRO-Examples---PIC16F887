   0:# INIT TABLES
   3:# 
   4:# ======= START RUNG 1 =======
   5:LabelRung1:
   6:
   7:set bit '$rung_top'
   9:# start series [
  10:# start parallel [
  11:clear bit '$parOut_0'
  12:let bit '$parThis_0' := '$rung_top'
  13:# start series [
  14:# ELEM_CONTACTS
  15:if not 'XSw1' {
  16:    clear bit '$parThis_0'
  17:}
  19:# ELEM_CONTACTS
  20:if not 'XSw2' {
  21:    clear bit '$parThis_0'
  22:}
  24:# ] finish series
  25:if '$parThis_0' {
  26:    set bit '$parOut_0'
  27:}
  28:let bit '$parThis_0' := '$rung_top'
  29:# start series [
  30:# ELEM_CONTACTS
  31:if 'XSw1' {
  32:    clear bit '$parThis_0'
  33:}
  35:# ELEM_CONTACTS
  36:if 'XSw2' {
  37:    clear bit '$parThis_0'
  38:}
  40:# ] finish series
  41:if '$parThis_0' {
  42:    set bit '$parOut_0'
  43:}
  44:let bit '$rung_top' := '$parOut_0'
  45:# ] finish parallel
  46:# ELEM_COIL
  47:let bit 'YLight' := '$rung_top'
  49:# ] finish series
  50:LabelRung2:
  51:
  52:# Latest INT_OP here
